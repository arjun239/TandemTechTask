package com.tandem.assignment.githubTests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.jayway.restassured.*;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.parsing.Parser;
import com.jayway.restassured.response.Response;
import static com.jayway.restassured.RestAssured.given;


public class GitHubIssuesTest
{
	 int milestone = 1;
	 String [] assignee = {"testAccount239"};
	 String [] labels = {"bug"};
	 final String token = "bearer" + "851eeb34166b78fb50c55da71bec8d2c90ea1859";
	 final String accountName = "testAccount239";
	 final String repoName = "testRepo";
@Test
 public void createIssue() {
	 
	
	
	RestAssured.defaultParser = Parser.JSON;
	Response response =
	given()
	.headers("Cache-Control","no-cache","Authorization",token,"Accept", "application/json", "Content-Type","application/json")
	.body("{\n" +
	                        " \"title\": \"This is a bug\",\n" +
	                        " \"body\": \"I am having a problem with this\",\n" +
	                        " \"assignees\": " + assignee[0] + ",\n" +
	                        " \"milestone\": " + milestone + ", \n" +
	                        " \"labels\": " + labels[0] +", \n" +
	                        "}")
	                       
	.when().post("https://api.github.com/repos/"+accountName+"/"+repoName+"/issues") 
	.then().contentType(ContentType.JSON).extract().response();
	Assert.assertTrue(response.getStatusCode() == 200, "Response status code is not 200, response status code is " + response.getStatusCode());
}
@Test 
public void editIssue() {
	
	RestAssured.defaultParser = Parser.JSON;
	Response response =
	given()
	.headers("Cache-Control","no-cache","Authorization",token, "Content-Type","application/json")
	.body("{\n" +
	                        " \"title\": \"This is a bug\",\n" +
	                        " \"body\": \"I am having a problem with this\",\n" +
	                        " \"assignees\": " + assignee[0] + ", \n" +
	                        " \"milestone\": " + milestone + ", \n" +
	                        " \"labels\": " + labels[0] +", \n" +
	                        "}")
	                       
	.when().post("https://api.github.com/repos/"+accountName+"/"+repoName+"/issues/2") 
	.then().contentType(ContentType.JSON).extract().response();
	Assert.assertTrue(response.getStatusCode() == 200, "Response status code is not 200, response status code is " + response.getStatusCode());
}
@Test
public void getIssues() {

RestAssured.defaultParser = Parser.JSON;
Response response =
given()
.headers("Authorization", token, "Cache-Control", "no-cache")
.when().get("https://api.github.com/repos/"+accountName+"/"+repoName+"/issues") 
.then().contentType(ContentType.JSON).extract().response();
Assert.assertTrue(response.getStatusCode() == 200, "Response status code is not 200, response status code is " + response.getStatusCode());
System.out.println(response.path("updated_at").toString());
 {
	
}

}
	}

